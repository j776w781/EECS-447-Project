import sys
sys.path.insert(0, '../library_project/mysql-connector-python/lib')
import mysql.connector

conn = mysql.connector.connect(
    user="447s25_j776w781",
    password="ohN7iewa",
    host="mysql.eecs.ku.edu",
    port=3306,
    database="447s25_j776w781"
)

cur = conn.cursor()

try:
    input_file = open("users.csv", 'r')
    query = "INSERT INTO user VALUES (%s,%s,%s,%s,%s,%s,%s)"
    for line in input_file:
        line = line.strip()
        line = line.split(", ")
        line[0] = int(line[0])
        line = tuple(line)
        cur.execute(query, line)
    conn.commit()
    conn.close()


except:
    print("bad")
    conn.close()
